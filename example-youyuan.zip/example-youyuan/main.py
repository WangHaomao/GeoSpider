# -*- encoding: utf-8 -*-
from scrapy import cmdline
import redis

r = redis.Redis(host='127.0.0.1', port=6379, db=0)
r.lpush('mycrawler:start_urls', 'http://taobao.com/')   #添加
cmdline.execute("scrapy crawl taobao".split())

# redis-cli lpush myspider:start_urls http://google.com