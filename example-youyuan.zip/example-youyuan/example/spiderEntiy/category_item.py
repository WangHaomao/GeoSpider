class category_item:
    def __init__(self,label,children_list,is_bottom):
        self.label = label
        self.children_list = children_list
        self.is_bottom = is_bottom
