# -*- coding:utf-8 _*-
import re
import requests
from lxml import etree
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

from example.spiderUtils.parser_util import get_soup_by_request_without_script,\
    get_soup_by_selenium_without_script,get_xpath_doc_by_request_by_html_source,get_soup_by_html_source

# 判断是否是商品列表的条件
"""
1、是否有足够的图片CONSEQUENT_SIMILAR_TAG_NUMBER个<img>标签
2、数量是否够多，在当前的wrapper中筛选符合条件1的 html数量最长的

后期可以添加筛选条件
"""
def check_is_goods_list(old_html_len,current_tag):
    CONSEQUENT_SIMILAR_TAG_NUMBER = 10
    tag_source = str(current_tag)
    img_len = len(get_soup_by_html_source(tag_source).find_all("img"))
    source_len = len(tag_source)
    if(img_len >= CONSEQUENT_SIMILAR_TAG_NUMBER and old_html_len < source_len):
        return source_len
    return  -1

def get_goods_list_tag_from_url(url):
    soup = get_soup_by_selenium_without_script(url)
    return get_goods_list_tag_from_soup(soup)

def get_goods_list_tag_from_soup(soup):
    # 按块查找，找到相似度较高且连续数高于某个值的外围后停止 ，每次选择当前区域内的最复杂区域（此处缩略为字符长最长的）
    # soup = soup = get_soup_by_request_without_script(url)
    has_find_goods_list = False
    max_len_tag = soup.find("body") #初始最大的外围
    goods_tag = max_len_tag
    deep = 0                        #查找深度
    SEARCH_DEEP_LIMIT = 20
    CONSEQUENT_SIMILAR_TAG_NUMBER = 10

    while(has_find_goods_list is False and deep < SEARCH_DEEP_LIMIT):

        max_len = 0
        tmp_max_len_tag = max_len_tag

        for child_tag in max_len_tag.children:
            # 排除不是tag的东西，比如\n，纯字符等等
            if(child_tag.name != None):
                # child_tag_len = len(str(child_tag))
                # if (child_tag_len > max_len):
                current_len =  check_is_goods_list(max_len,child_tag)
                if (current_len!=-1):
                    max_len = current_len
                    tmp_max_len_tag = child_tag



        max_len_tag = tmp_max_len_tag
        # 用来判断是否有多余的属性，初次属性设置为全都一样才算list
        """ 筛选条件：（筛选的缩放宽度）
            版本1：所有的 attributes 都一样
            版本2：允许出现两种以下的attributes
        """
        all_attrs = set()
        number_of_effective_children = 0
        tag_list_name = ""

        is_goods_list = True
        # 测试是否符合要求
        for child_tag in max_len_tag.children:

            if(child_tag.name != None):
                # print child_tag.attrs
                tag_attrs = child_tag.attrs
                if(number_of_effective_children == 0):
                    tag_list_name = child_tag.name
                    for key in tag_attrs.keys():
                        all_attrs.add(key)
                else:

                    if(tag_list_name!=child_tag.name):
                        is_goods_list = False
                        break

                    for key in tag_attrs.keys():
                        if(key not in all_attrs):
                            is_goods_list = False
                            break
                    if(is_goods_list is False): break

                number_of_effective_children+=1

        # 同一个中某个标签大于10且服务条件
        if(number_of_effective_children>CONSEQUENT_SIMILAR_TAG_NUMBER and is_goods_list):
            has_find_goods_list = True
            goods_tag = max_len_tag

        deep+=1
    return max_len_tag

def get_goods_url_from_tag(wrapper_tag):
    goods_url_list = []
    for tag in wrapper_tag:
        if(tag.name != None):
            doc = etree.HTML(str(tag))
            a_list = doc.xpath("//a[@href]/@href")
            print  a_list[0]
            # print a_list


if __name__ == '__main__':

    # url = "https://search.jd.com/Search?keyword=%E6%89%8B%E6%9C%BA&enc=utf-8&suggest=1.his.0.0&wq=&pvid=9e4453eb3e86474c9f0d8ce8719b03aa"
    url = "https://s.taobao.com/search?initiative_id=tbindexz_20170509&ie=utf8&spm=a21bo.50862.201856-taobao-item.2&sourceId=tb.index&search_type=item&ssid=s5-e&commend=all&imgfile=&q=%E6%89%8B%E6%9C%BA&suggest=0_1&_input_charset=utf-8&wq=shouji&suggest_query=shouji&source=suggest"
    # url = "view-source:https://s.taobao.com/search?spm=a230r.1.0.0.iSIJK2&q=%E6%89%8B%E6%9C%BA&spu_title=%E5%8D%8E%E4%B8%BA+P10&app=detailproduct&pspuid=1487030&cat=1512&from_pos=20_1512.default_0_2_1487030&spu_style=grid"
    # url = "http://list.mogujie.com/s?q=%E6%89%8B%E6%9C%BA%E5%A3%B3%E8%8B%B9%E6%9E%9C6&from=querytip0&ptp=1._mf1_1239_15261.0.0.5u1T9Y"
    # url = "http://search.dangdang.com/?key=%CA%E9&act=input"
    # url = "http://search.suning.com/%E6%89%8B%E6%9C%BA/"
    # soup = get_soup_by_request_without_script(url)

    soup = get_soup_by_selenium_without_script(url)

    # 已经获得
    goods_list_tag = get_goods_list_tag_from_soup(soup)


    '''
        暂时不考虑没attribute的标签
    '''
    print goods_list_tag
    # print goods_list_tag.name
    # print goods_list_tag.attrs
    #
    tag_name = goods_list_tag.name
    attrs_dic =  goods_list_tag.attrs
    #


    # print soup.find_all(tag_name,attrs=attrs_dic)


    # get_goods_url_from_tag(goods_list_tag)
