#-*- coding:utf-8 -*-
from bs4 import BeautifulSoup,Comment
from selenium import webdriver
import requests
from example.spiderEntiy.category_item import category_item

# def dfs(tag,paStr):
#     tag_children = tag.children
#     tag_contents = tag.contents
#
#     if (tag_children != None and len(list(tag_children))!=0):
#         children_count = 1
#         flag = False
#         child_list = []
#         for ch_tag in tag_contents:
#             # if ch_tag.name == None:
#             #     print paStr
#             # else:
#             if ch_tag.name != None:
#                 flag = True
#                 nextStr = paStr+"/"+ ch_tag.name
#                 dfs(ch_tag,nextStr)
#                 children_count +=1
#
#                 child_list.append(nextStr)
#         if(flag == False): print paStr
#
#
#     else:return paStr
#
# def pageAnalyst(url):
#     resq = requests.get(url)
#     soup = BeautifulSoup(resq.text,"lxml")
#     # [script.extract() for script in soup.findAll('script')]
#     # [style.extract() for style in soup.findAll('style')]
#     # comments = soup.findAll(text=lambda text: isinstance(text, Comment))
#     # [comment.extract() for comment in comments]
#
#
#     # print soup.prettify()
#
#     ul_list = soup.find_all("ul")
#     # for ulx in ul_list:
#     # for string in soup.stripped_strings:
#     #     print(repr(string))
#     #
#     # print ul_list[0]
#     # print ""
#     # print ""
#     # for x in ul_list[0].children:
#     #     # y = x.stripped_strings
#     #     if(x.string != '\n'):
#     #         print "[%s,%s]"%(x.name,x.string)
#     #
#     #     if x.name != None:
#     #         print x.name
#     #         for y in x.children:
#     #             if y.name is not None:
#     #                 print "  "+y.name
#     #                 for z in y.children:
#     #                     if z.name is not None:
#     #                         print "    " + z.name
#
#     deep = 1
#     tag_name = ul_list[0].name
#     for x in ul_list[0].children:
#         # print x.name
#         if x.name is not None:
#             dfs(x,tag_name+"/"+x.name)
#             deep+=1
#
#
#     # print ul_list[0].contents

# url = "https://www.taobao.com/tbhome/page/market-list"


def get_tag_path(tag):
    parent_tag = tag.parent
    tag_path_stack = []
    tag_path_stack.append("/%s" % tag.name)
    while parent_tag != None and parent_tag.name != None:
        if (parent_tag.name == "html"):
            tag_path_stack.append("%s" % parent_tag.name)
            break

        tag_path_stack.append("/%s" % parent_tag.name)
        parent_tag = parent_tag.parent

    tag_path_stack.reverse()
    tag_path = "".join(tag_path_stack)

    return tag_path

def pageAnalyst(url):
    resq = requests.get(url)
    soup = BeautifulSoup(resq.text,"lxml")
    # resq.encoding = "utf-8"
    # soup.encode("utf-8")
    # driver = webdriver.PhantomJS()
    # driver.get(url)
    # page = driver.page_source
    # print  "getpage over!"
    # soup = BeautifulSoup(page, 'lxml')
    # driver.close()
    # [script.extract() for script in soup.findAll('script')]
    # [style.extract() for style in soup.findAll('style')]
    # comments = soup.findAll(text=lambda text: isinstance(text, Comment))
    # [comment.extract() for comment in comments]

    tagPath_to_appearCount = {}
    tagPath_to_allTagInPath = {}

    max_appear_tag_path = ""
    max_appear_tag_number = 0

    for current_tag in soup.find_all("a"):

        # get 'tag-path' such as html/body/div/div/ul/li/a
        tag_path = get_tag_path(current_tag)

        # Has 'tag-path' been appeared
        if(tagPath_to_appearCount.has_key(tag_path) is True):
            tagPath_to_appearCount[tag_path] +=1
            tagPath_to_allTagInPath[tag_path].append(current_tag)
        else:
            tagPath_to_appearCount[tag_path] = 1
            tagPath_to_allTagInPath[tag_path] = []
            tagPath_to_allTagInPath[tag_path].append(current_tag)

    sorted_tag_path_list = sorted(tagPath_to_appearCount.items(), key=lambda d: d[1], reverse=True)
    # for item in sort:
    #     print  "%s %s" % (sorted_tag_path_list[0], sorted_tag_path_list[1])

    all_category = tagPath_to_allTagInPath[sorted_tag_path_list[0][0]]
    category_res_list = []
    category_name_set = set()
    # for tag in all_category:
    #     # if(category_name_set)
    #     # parent_deep =  1
    #     #
    #     # while(parent_deep <=3 and tag.text != None and len(tag.text)!=0):
    #     #
    #     #
    #     #
    #     #     parent_deep+=1
    #
    #
    #     print "-----------one menu----------------"
    #
    #     parent_tag = tag.parent
    #     # print parent_tag.text
    #
    #
    #
    #     parent_tag = parent_tag.parent
    #     # print parent_tag.text
    #     #
    #     parent_tag = parent_tag.parent
    #     print parent_tag.text
    #     print "-----------one menu----------------"
    #     # while parent_tag != None and parent_tag.name != None:
    #

    # parent_threshold_num = sorted_tag_path_list[int(len(sorted_tag_path_list)/3)][1]
    # category_menu_1_list = []
    #
    # print parent_threshold_num
    sorted(tagPath_to_appearCount.items(), key=lambda d: d[1])
    for key, value in tagPath_to_appearCount.items():
        print key, ':', value
        if(max_appear_tag_number < value):
            max_appear_tag_number = value
            max_appear_tag_path = key

    all_category_tag_list = tagPath_to_allTagInPath[max_appear_tag_path]
    print len(all_category_tag_list)
    for tag in all_category_tag_list:
        print str(tag)
    # for xx in tagPath_to_allTagInPath['html/body/div/div/ul/li/a']:
    #     print str(xx)

# url = "http://category.dangdang.com/?ref=www-0-C"
# url = "https://www.taobao.com/tbhome/page/market-list?spm=a21bo.50862.201867-main.1.kjqEuo"

# url = "https://www.taobao.com/tbhome/page/market-list?spm=a21bo.50862.1997563209.1.tN3Q8e"
url = "https://search.jd.com/Search?keyword=%E6%89%8B%E6%9C%BA&enc=utf-8&suggest=1.def.0.T13&wq=sho&pvid=585820b970c24bf082540d0f0784c31c"
#pageAnalyst(url)
url = "https://s.taobao.com/search?app=mainSrp&q=%E5%A4%A9%E6%A2%AD&cd=false"
print requests.get(url).text
