from url_utils import *

print urlSifter("https://www.taobao.com/","//www.taobao.com/tbhome/page/market-list")