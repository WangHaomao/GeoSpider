mylist = []
mylist.append("123")
mylist.append("321")
for my in range(0,len(mylist)):
    mylist[my]  = mylist[my]  +"11111"

print mylist[0]
print mylist[1]