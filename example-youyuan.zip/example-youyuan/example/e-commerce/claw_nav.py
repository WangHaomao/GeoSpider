# -*- encoding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
from nav_selector import scoring
from nav_selector import loadFeature
import re
import sys
reload(sys)
sys.setdefaultencoding('utf8')


from selenium import webdriver
# strategy e-commerce get link from the keyword = "分类" or "商品分类"
# 返回一个url或空值，空即是没找到，执行下一步
def getAllCategoryFromKey(soup):
    keyword = [u"全部商品分类",u"商品分类",u"全部分类",u"分类",]
    for label_i in range(0, 4):
        a_key = soup.find_all(True, text=re.compile(keyword[label_i]))
        for a in a_key:
            # print  a
            if "</script>" in str(a):
                # print re.findall("{.+?}",str(a))
                for tmp in re.findall("{.+?}",str(a)):
                    if(keyword[label_i] in str(tmp)):
                        key_value = tmp.split(",")
                        for kv in key_value:
                            tmp_kv = kv.split(":")
                            key = tmp_kv[0]
                            value = tmp_kv[1]
                            #能否判断value是url,不能就用以下方法
                            if key =='"url"' :
                                return value
            else:
                deep = 1
                a_copy = a
                while(deep < 5):
                    soup_tmp = BeautifulSoup(str(a_copy), "lxml")
                    res_a= soup_tmp.find_all("a")
                    if len(res_a)!=0:
                        for a_list in res_a :
                            return a_list.get("href")
                        break

                    a_copy = a_copy.parent
                    # print  a_copy
                    deep += 1

    for label_i in range(0, 4):
        for sin_a in soup.find_all("a"):
             if keyword[label_i] in str(sin_a):
                  return sin_a.get("href")

    return None


# strategy2 class = nav
def getNavByClassNav(soup):
    all_element = soup.find_all("ul",class_= re.compile("nav"))
    navUl = scoring(all_element, loadFeature('../../e-commerce.txt'), url)
    if navUl is None:
        all_element = soup.find_all("div",class_= re.compile("nav"))
        navUl = scoring(all_element, loadFeature('../../e-commerce.txt'), url)

    print navUl




# strategy3 all by select ul
def getNavFromUl(soup):
    all_ul = soup.find_all('ul')
    print scoring(all_ul, loadFeature('../../e-commerce.txt'), url)

# strategy4 还未完成，需要找子节点
def getNavFromDiv(soup):
    all_ul = soup.find_all('div')
    scoring(all_ul, loadFeature('../../e-commerce.txt'), url)

def debug(debug_info):
    print "debug:%s"%debug_info
#淘宝
url = 'https://www.taobao.com/'
# 当当
# url = "http://www.dangdang.com/"

#唯品会
# url = "http://www.vip.com/"
#凡客诚品
# url = "http://www.vancl.com/"
#一号店
# url = "http://club.yhd.com/"
# url = "http://www.yhd.com/"
#亚马逊
# url = "https://www.amazon.cn/"
#amazon USA
# url = 'https://www.amazon.com/'
# 美丽说
# url = "http://www.meilishuo.com/"


# res = requests.get(url)
# soup = BeautifulSoup(res.text, 'lxml')
# print res.text
# for x in  soup.find_all("a"):
#     print str(x)
# driver = webdriver.PhantomJS()
# driver.get(url)
# page = driver.page_source
# soup = BeautifulSoup(page, 'lxml')

# driver.close()
# step 1
# getAllCategoryFromKey(soup)
# step 2
# getNavFromUl(soup)
# setp 3
# getNavByClassNav(soup)

from example.spiderUtils.url_utils import urlSifter
from example.pageParser.category_page_parser import pageAnalyst
if __name__ == '__main__':
    res = requests.get(url)
    soup = BeautifulSoup(res.text, 'lxml')
    categoryURL =  urlSifter(url,getAllCategoryFromKey(soup))

    print  categoryURL

    # pageAnalyst(categoryURL)
