# -*- encoding: utf-8 -*-
from bs4 import BeautifulSoup
'''
    author:Yangkui
'''
#加载特征数据
def loadFeature(fileName):
    fr = open(fileName, 'r')
    arrayLines = fr.readlines()
    featureDict = {}
    for line in arrayLines:
        line = line.strip()
        line = line.split(' ')
        featureDict[line[0]] = line[1]
        #print line[0]+" "+line[1]
    return featureDict

#计算得分
def scoring(ulData, featureDict,indexURL):
    scoreList = []
    hrefList = []
    index = 0
    fitting_index = 0
    fitting_score = -1

    # 避免url不完整的情况 step1
    # 这里还有问题，比如http://club.yhd.com/这恶果网站，以club开头
    url_domain = ''
    if 'https://www.' in indexURL:
        url_domain = indexURL.replace('https://www.','')
    elif "http://www." in indexURL:
        url_domain = indexURL.replace('http://www.', '')


    for ul in ulData:
        # print ul
        score = 0

        soup2 = BeautifulSoup(str(ul), 'lxml')
        # find out all <a> tag of one <ul>
        alist = soup2.find_all('a')
        if len(alist) != 0:
            for a in alist:
                soup3 = BeautifulSoup(str(a).strip(), 'lxml')
                content = soup3.a.text.strip().encode('utf8')

                href_list = soup3.find_all("a")
                # print href_list
                # if content != '' and content is not None and href !='' and href is not None:
                if content != '' and content is not None :
                    # and len(href_list) != 0 and str(href_list[0]) != ''
                    for key in featureDict.keys():
                        if content in key or key in content:
                            score += int(featureDict.get(key))
                            # print  content
                            break


                    # 避免url不完整的情况 step1
                    # for i in range(0,len(href_list)):
                    #     if (str(href_list[i]).startswith("//")):
                    #         if url_domain not in href_list[i]:
                    #             href_list[i] = indexURL + href_list[i]

        print "score=%d" %score
        scoreList.append(score)
        if fitting_score < score:

            fitting_index = index
            fitting_score = score

        index += 1
    # 符合
    print fitting_index
    if(len(scoreList)>0 and scoreList[fitting_index] >= 4):
        return ulData[fitting_index]
    else:return None
if __name__ == "__main__":
    dict = loadFeature('../../e-commerce.txt')
    # print dict.items()
    # print dict.get('数码')